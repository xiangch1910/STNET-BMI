# import torchvision
# import torch.nn as nn
# import torch
#
# class resenet2d(nn.Module):
#     def __init__(self, n_classes=1):
#         super(resenet2d, self).__init__()
#         a=torchvision.models.resnet152()._modules
#         self.layer1=nn.Sequential(a["conv1"],a["bn1"],a['relu'],a['maxpool'],a["layer1"],a["layer2"])
#         self.layer2=nn.Linear(512,n_classes)
#
#     def forward(self, x):
#         out = self.layer1(x).mean(-1).mean(-1)
#         out=self.layer2(out)
#         return out

import torchvision
import torch.nn as nn
import torch
#from gcblock import ContextBlock

class resnet2d(nn.Module):
    def __init__(self, n_classes=1):
        super(resnet2d, self).__init__()
        # self.attention1 =ContextBlock(64)
        # self.attention2 =ContextBlock(256)
        # self.attention3 =ContextBlock(512)
        # self.attention4 =ContextBlock(1024)
        a=torchvision.models.resnet18(pretrained=True)._modules
#         self.layer1=nn.Sequential(a["conv1"],a["bn1"],a['relu'],a['maxpool'],a["layer1"],a["layer2"])
#         self.layer2=nn.Linear(512,n_classes)
        self.layer0=nn.Sequential(a["conv1"],a["bn1"],a['relu'],a['maxpool'])
        self.layer1=nn.Sequential(a["layer1"])
        self.layer2=nn.Sequential(a["layer2"])
        self.layer3=nn.Sequential(a["layer3"])
        self.layer4=nn.Sequential(a["layer4"])

        self.avgpool = nn.Sequential(a["avgpool"])
        self.fc=nn.Linear(2048,n_classes)
    def forward(self, x):
        out=self.layer0(x)
        #out=self.attention1(out)
        out=self.layer1(out)
        out=self.layer2(out)
        out=self.layer3(out)
        out=self.layer4(out)
        out=torch.flatten(out,1)
        #out=out.mean(-1).mean(-1)
        out=self.fc(out)
        return out